# Elite Estates — Real Estate Website

## Project files
- `index.html` — homepage, search, featured listings, about, contact form
- `property.html` — dynamic property details page (uses `?id=1` etc.)
- `style.css` — responsive styling, animations, light/dark themes
- `script.js` — property data, search/filtering, favorites, theme, navigation, details, contact form

## Run locally
Open `index.html` in a browser. For best results, use VS Code with the Live Server extension.

## Important notes
- Property listings are sample/demo content. Replace the sample names, prices, locations and descriptions with verified listings before publishing.
- Property photos load from Unsplash, and Google Fonts load online, so an internet connection is needed for those assets.
- The contact form validates the fields and opens the visitor's default email application with a prepared message. For automatic server-side delivery, connect a form backend such as Formspree or your own API and replace the `mailto:` handler in `script.js`.
- The example contact address uses `hello@eliteestates.example`; replace it with your real business email in `index.html` and `script.js`.
- This is a front-end demo. It does not include user accounts, a database, or a property management dashboard.
